#!/usr/bin/env bash
flake8 --exclude venv --max-line-length 100
